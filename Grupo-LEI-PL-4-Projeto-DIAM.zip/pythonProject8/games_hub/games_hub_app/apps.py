from django.apps import AppConfig


class GamesHubAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'games_hub_app'
